//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var coordinates = (40,20)

switch coordinates{
case (0,0):
    print("Start of canvas")
case(100,100):
    print("End of canvas")
case(10,20):
    print("Center of canvas")
case(10,_):
    print("X axis")
case(_,20):
    print("Y axis")
case(101...200,101...200):
    print("Outside the canvas")
default:
    print("Canvas unavailable")
}

var range = 1...100
print(range)
print(range.contains(45))
print(range.contains(453))
print("Lowerbound", range.lowerBound)
print("Upperbound", range.upperBound)

for itr in 0..<5{
    print("itr : \(itr)")
}

var friends = ["Simran", "Anu", "Aman", "Prabnjeet"]
var length = friends.count

for itr in 0..<length{
    print("Friends : \(friends[itr])")
}

for frnd in friends[1...]{
    print("====\(frnd)")
}
for frnd in friends[...2]{
    print("@@@\(frnd)")
}

for char in "Good 🤪"{
    print("Character : \(char)")
}

var govinda = """
Answer to yesterday's question
what could you have been instead of being teacher?
You know about the answer.
Response::I don't know.
"""

govinda += "I would be an Astronaut"
govinda.append(" ohhh really !!!🧐 \u{1F496}")
print(govinda)

var value = String()
//value = "too much"

if value.isEmpty{
    print("Value is not available")
}else{
    print(value)
}

var day = "Saturday"
//Saturday_
print("startIndex : \(day[day.startIndex])")
//print("endIndex : \(day[day.endIndex])")

print("Last character : \(day[day.index(before:day.endIndex)])")

print("Second character : \(day[day.index(after:day.startIndex)])")

print("4th character : \(day[day.index(day.startIndex, offsetBy:3)])")

print("3rd from last : \(day[day.index(day.endIndex,offsetBy: -3)])")

var index = day.index(of: "t") ?? day.startIndex
print("char t : \(day[index])")

for idx in day.indices{
    print("\(day[idx])",terminator: "_")
}
print()
print("test")

for (idx,char) in day.enumerated(){
    print("Index : \(idx) Char : \(char)")
}

print(day.uppercased())
print(day.lowercased())

day.insert("!", at: day.endIndex)
print(day)

day.insert(contentsOf: " No class please", at: day.endIndex)
print(day)

var idx1 = day.index(of: "!") ?? day.endIndex
day.remove(at: idx1)
print(day)

idx1 = day.index(of: "N") ?? day.endIndex
var idx2 = day.index(of: "s") ?? day.endIndex
day.removeSubrange(idex1...id2)
print(day)
//Saturday s please-output

day.removeAll()
print("day : ",day)








